package com.example.fragmentsinandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class static_fragments_list_example : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_static_fragments_list_example)
    }
}