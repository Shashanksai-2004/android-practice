package com.example.fragmentsinandroid

interface FragmentColorInterface {
    fun newColor(color : Int)
}