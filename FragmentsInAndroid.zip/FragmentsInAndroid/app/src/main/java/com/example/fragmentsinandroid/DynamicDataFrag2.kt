package com.example.fragmentsinandroid

import android.os.Bundle
import android.os.Message
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView


class DynamicDataFrag2 : Fragment() {

    lateinit var txtData : TextView
    var msg : String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view : View = inflater.inflate(R.layout.fragment_dynamic_data_frag2,container,false)
        txtData = view.findViewById(R.id.textView)
        txtData.setText(msg)
        return view
    }

    fun displayReceivedData(message: String){
        msg = message
    }
}