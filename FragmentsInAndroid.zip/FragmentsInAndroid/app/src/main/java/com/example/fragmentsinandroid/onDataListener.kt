package com.example.fragmentsinandroid

interface onDataListener {
    fun communicate(msg:String)
}