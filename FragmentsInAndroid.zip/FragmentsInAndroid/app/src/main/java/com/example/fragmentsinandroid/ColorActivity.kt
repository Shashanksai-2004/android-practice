package com.example.fragmentsinandroid

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment

class ColorActivity : AppCompatActivity(),FragmentColorInterface {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_color)
    }

    fun changeColor(v : View){
        val fragment2 = supportFragmentManager
            .findFragmentByTag("frag2") as BottomFragment
        fragment2.updateColor(Color.BLACK)
    }

    override fun newColor(color : Int) {
        val fragment2 = supportFragmentManager
            .findFragmentByTag("frag2") as BottomFragment

        fragment2.updateColor(color)
    }
}