package com.example.fragmentsinandroid

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class DynamicFragmentActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dynamic_fragment)

        val fm : FragmentManager = supportFragmentManager
        val fragmentTransaction : FragmentTransaction = fm.beginTransaction()
        val displaymode = resources.configuration.orientation
        if(displaymode == 1){ // if portrait mode
            val f1 = DynamicFrag1()
            fragmentTransaction.replace(android.R.id.content,f1)
        }else{ // if landscape mode
            val f2 = DynamicFrag2()
            fragmentTransaction.replace(android.R.id.content,f2)
        }
        fragmentTransaction.commit()
    }
}